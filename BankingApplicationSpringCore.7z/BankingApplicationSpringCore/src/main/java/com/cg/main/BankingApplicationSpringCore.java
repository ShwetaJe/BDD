package com.cg.main;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cg.bean.Customer;
import com.cg.controller.HomeController;
import com.cg.service.CustomerService;

@SpringBootApplication
@EnableJpaRepositories(basePackages="com.*")
@EntityScan(basePackages="com.*")
@ComponentScan(basePackages="com.*")
@EnableAutoConfiguration
/* @EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class}) */
public class BankingApplicationSpringCore extends SpringBootServletInitializer implements CommandLineRunner {

	@Autowired
	CustomerService service;
	
	
	public SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(BankingApplicationSpringCore.class);

	}

	public static void main(String[] args) {

		SpringApplication.run(BankingApplicationSpringCore.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		Customer c;
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		//boolean logoutFlag = false;
		String choice = null;
		System.out.println("******* Welcome to Bank Application in SpringCore *******");
		System.out.println("1. Create an Account");
		System.out.println("2. Show Balance");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions");
		System.out.println("7. Exit");
		choice = sc.next();
		String name = "", mobNo = "", address = "";
		Double amount = 0d;

		while (true) {
			boolean flag = true;
			switch (choice) {

			case "1":/// create

				c = new Customer();
				System.out.print("Enter Name:");
				name = sc1.nextLine();
				c.setCustNAme(name);

				System.out.print("Mobile Number:");
				mobNo = sc.next();
				c.setMobNo(mobNo);
				System.out.print("Address: ");
				address = sc.next();
				c.setAddress(address);

				System.out.print("Balance: ");
				amount = Double.parseDouble(sc.next());
				c.setBalc(amount);
				c.setWallet(0d);
				//ctrl.createAcc(c);
				service.addAccount(c);
				break;

			case "2":
				
			
				System.out.print("Enter Mob No:");
				mobNo = sc1.nextLine();
				
				Customer cu = service.getAccount(mobNo);
				System.out.println("Bank Balance: " + service.getAccount(mobNo).getBalc());
				System.out.println("Wallet Balance: " + service.getAccount(mobNo).getWallet());
				
//			
//
//				if (account) {
//					CSAccount acc = ctrl.getAccount(acId);
//					System.out.println(
//							"\n\n-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-*\n\t\t\t\tWELCOME "
//									+ acc.getName());
//
//					boolean flag = true;
//					while (flag) {
//						if (!logoutFlag) {
//							System.out.println(
//									"------------------------------------MENU--------------------------------------\n1.Show Balance\t\t2.Deposit in bank account\t3.Add money to wallet\n4.Pay From wallet\t5.Transfer back from wallet\t6.Print Transaction\n7.Logout\n------------------------------------------------------------------------------\nEnter Your Choice: ");
//							choice = sc.next();
//						}
//						switch (choice) {
//						case "1":/// show balance
//							System.out.println("Bank Balance: " + ctrl.showAccountBalance(acId));
//							System.out.println("Wallet Balance: " + ctrl.showWalletBalance(acId));
							break;

						case "3":
							System.out.print("Enter Mob No:");
							mobNo = sc1.nextLine();
							System.out.print("Amount: ");

							amount = Double.parseDouble(sc.next());

							service.deposit(amount, mobNo);
							System.out.println("Bank Balance: " + service.getAccount(mobNo).getBalc());
							System.out.println("Wallet Balance: " + service.getAccount(mobNo).getWallet());
							break;

						case "4":// transfer money form bank to wallet
							c = new Customer();
							System.out.print("Enter Mob No:");
							mobNo = sc1.nextLine();
							c.setMobNo(mobNo);
						System.out.print("Amount: ");
						
								amount = Double.parseDouble(sc.next());
								
						service.withDraw(amount, mobNo);
					
							break;

						case "5":// withdraw form wallet
		
							c = new Customer();
							System.out.print("Enter Mob No:");
							mobNo = sc1.nextLine();
							
						System.out.print("Enter Receiver Mob No: ");
						String receiverMobNo = sc.next();
						System.out.print("Amount: ");
						amount = Double.parseDouble(sc.next());
						service.bankToWallet(amount, receiverMobNo);

							break;

						case "6":// transfer money back to bank

//							System.out.print("Amount: ");
//							
//									amount = Double.parseDouble(sc.next());
//									
//							ctrl.walletToBank(acId, amount);

							break;
				
//						case "7":
//							
//							flag = false;
//							//logoutFlag = true;
//							break;
//						default:
//							System.out.println("Invalid Choice");
//							flag = false;
//							break;
//						}
//
//					}
//				}
//
//				else {
//					System.out.println("Invalid Account Number or Password.");
//				}
//				break;
//
//			case "3":
//				Iterable<Customer> accounts = ctrl.getAll();
//
//				accounts.forEach(System.out::println);
//				break;

			case "7":
				sc.close();
				sc1.close();
				
				System.out.println("Thank You.");
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Choice.");
				break;
			}
			System.out.println("******* Welcome to Bank Application in SpringCore *******");
			System.out.println("1. Create an Account");
			System.out.println("2. Show Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transactions");
			System.out.println("7. Exit");
			choice = sc.next();
		}

	}

}
