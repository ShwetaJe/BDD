package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.Customer;
import com.cg.dao.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository repo;
	Customer cust;
	
	public String addAccount(Customer customer) {
		customer.setAccNo((int)(Math.random() * 1000000));
		repo.save(customer);
		
		return "your Account Id is: "+customer.getMobNo();
	}
	
	public Customer deposit(double amount, String mobNo) {
		cust = repo.findById(mobNo).get();
		cust.setBalc(cust.getBalc()+amount);
		repo.save(cust);
		
		return cust;
	}
	
	public Customer withDraw(double amount, String mobNo) {
		cust = repo.findById(mobNo).get();
		cust.setBalc(cust.getBalc()-amount);
		repo.save(cust);
		
		return cust;
	}
	
	public Customer bankToWallet(double amount, String mobNo) {
		cust = repo.findById(mobNo).get();
		if(cust.getBalc()>=amount) {
			cust.setBalc(cust.getBalc()-amount);
			cust.setWallet(cust.getWallet()+amount);
			repo.save(cust);
		}
		return cust;
	}
	
	public Customer getAccount(String mobNo) {
		// TODO Auto-generated method stub
		return repo.findById(mobNo).get();
	}


	public Iterable<Customer> getAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
}
