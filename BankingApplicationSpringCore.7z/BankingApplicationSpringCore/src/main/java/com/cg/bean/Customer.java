package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	private String custNAme;
	private int accNo;
	private double balc;
	private String address;
	@Id
	private String mobNo;
	private double wallet;
	
	@Override
	public String toString() {
		return "Customer [custNAme=" + custNAme + ", accNo=" + accNo + ", balc=" + balc + ", address=" + address
				+ ", mobNo=" + mobNo + ", wallet=" + wallet + "]";
	}
	
	public Customer(String custNAme, int accNo, double balc, String address, String mobNo, double wallet) {
		super();
		this.custNAme = custNAme;
		this.accNo = accNo;
		this.balc = balc;
		this.address = address;
		this.mobNo = mobNo;
		this.wallet = wallet;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCustNAme() {
		return custNAme;
	}
	public void setCustNAme(String custNAme) {
		this.custNAme = custNAme;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	public double getBalc() {
		return balc;
	}
	public void setBalc(double balc) {
		this.balc = balc;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobNo() {
		return mobNo;
	}
	public void setMobNo(String mobNo) {
		this.mobNo = mobNo;
	}
	public double getWallet() {
		return wallet;
	}
	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

}
