package com.cg.exception;

public class PWAException extends Exception{

	public PWAException(String message) {
		super(message);
	}

}
