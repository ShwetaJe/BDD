package com.cg.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.cg.bean.Customer;



public interface CustomerRepository extends CrudRepository<Customer,String>{
	

	 

}
