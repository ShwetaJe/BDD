package com.cg.controller;



import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.Customer;
import com.cg.service.CustomerService;


public class HomeController {


	@Autowired
	CustomerService service;

	Customer cust;


		public void createAcc(Customer customer) {

			service.addAccount(customer);
		}


	public void depositAmount(double amount,String mobNo)
	{
		cust=service.deposit(amount,mobNo);
	}


	public void withdrawAmount(double amount)
	{
			cust=service.withDraw(amount,cust.getMobNo());
	}

	public void bankToWallet(double amount,String mobNo)
	{
			cust=service.bankToWallet(amount,mobNo);
	}


	public Customer getAccount(String mobNo) {

		return service.getAccount(mobNo);
	}


	public Double showAccountBalance(String mobNo) {

		return service.getAccount(mobNo).getBalc();
	}


	public Double showWalletBalance(String mobNo) {

		return service.getAccount(mobNo).getBalc();
	}


	public Iterable<Customer> getAll() {
		// TODO Auto-generated method stub
		return service.getAll();
	}
	
	
}
