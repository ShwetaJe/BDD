package com.cg.BankApp.entity;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.springframework.stereotype.Component;

@Entity
@Table(name="Accounts")
@Component
public class Account {
	@Id
	private Long accountNo;
	private String mobileNo;
	private String name;
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private int balance;
	private String email;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(Long accountNo, String mobileNo, String name,int balance,String email) {
		super();
		this.accountNo = accountNo;
		this.mobileNo = mobileNo;
		this.name = name;
		this.email=email;
		this.balance=balance;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", mobileNo=" + mobileNo + ", name=" + name
				+ "]";
	}
	
}
