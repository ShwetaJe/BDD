package com.cg.BankApp.service;


import java.util.List;

import com.cg.BankApp.entity.Account;


public interface IAccountService {
	public Account createAccount(Account customer);
	public double showBalance(Long accountNo);
	public boolean fundTransfer (Long tAccountNumber, Long rAccountNumber, int amount);
	public boolean depositAmount(Long accountNo,int amount);
	public boolean withdrawAmount(Long accountNo,int amount);
	public List<Account> display();
	
	

}
