package com.cg.BankApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.BankApp.dao.AccountRepository;
import com.cg.BankApp.entity.Account;



@Service
public class AccountService implements IAccountService{

	@Autowired
    AccountRepository repo;
	
	@Autowired
	Account account;


	@Override
	public Account createAccount(Account customer) {
		// TODO Auto-generated method stub
		return repo.save(customer);
	}

	@Override
	public double showBalance(Long id) {
		Account acc=new Account();
		acc=repo.findById(id).get();
		return acc.getBalance();
	}

	@Override
	public boolean fundTransfer(Long tAccountNumber, Long rAccountNumber, int amount) {
		Account acc=new Account();
		acc=repo.findById(tAccountNumber).get();
		if(acc.getBalance()>0) {
		acc.setBalance(acc.getBalance()-amount);
		Account acc1=new Account();
		acc1=repo.findById(rAccountNumber).get();
		acc1.setBalance(acc1.getBalance()+amount);
		return true;
		}
		return false;
	}

	@Override
	public boolean depositAmount(Long accountNumber, int amount) {
		Account acc1=new Account();
		acc1=repo.findById( accountNumber).get();
		acc1.setBalance(acc1.getBalance()+amount);
		return false;
	}

	@Override
	public boolean withdrawAmount(Long accountNumber, int amount) {
		Account acc1=new Account();
		acc1=repo.findById( accountNumber).get();
		acc1.setBalance(acc1.getBalance()-amount);
		return false;
	}

	@Override
	public List<Account> display() {
		List<Account>list=(List<Account>) repo.findAll();
		return list;
	}

}
