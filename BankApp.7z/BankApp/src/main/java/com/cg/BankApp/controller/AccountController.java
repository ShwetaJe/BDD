package com.cg.BankApp.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.BankApp.entity.Account;

import com.cg.BankApp.service.IAccountService;

@RestController
public class AccountController {
	
	@Autowired
	private IAccountService service;
	@Autowired
	private Account account;
	

	
	@PostMapping(value="/createaccount")
	public Account createAccount(@RequestBody Account account) {
		
		return service.createAccount(account);
	}
	
	@GetMapping(value="/showbalance/{accountNo}")
	public double showBalance(@PathVariable Long accountNo) {
		return service.showBalance(accountNo);
	}
	@PostMapping(value="/deposite/{accountNo}/{amount}")
	public void deposit(@PathVariable Long accountNo,@PathVariable int amount) {
	 service.depositAmount(accountNo, amount);
	}
	@PostMapping(value = "/withdraw/{accountNo}/{amount}")
	public void withdraw(@PathVariable Long accountNo,@PathVariable int amount) {
		System.out.println(accountNo+"--"+amount);
		service.withdrawAmount(accountNo, amount);
	}
	
	@PostMapping(value="/fundtransfer/{tAccountNumber}/{rAccountNumber}/{amount}")
	public void fundT(@PathVariable Long tAccountNumber,@PathVariable Long rAccountNumber,@PathVariable int amount) {
	 service.fundTransfer(tAccountNumber, rAccountNumber, amount);	
}
	@GetMapping(value="/displayAll")
	public List<Account> display(){
		return service.display();
	}
}